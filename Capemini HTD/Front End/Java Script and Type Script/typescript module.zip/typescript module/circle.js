"use strict";
exports.__esModule = true;
var Circle = /** @class */ (function () {
    function Circle() {
    }
    Circle.prototype.circumference = function (r) {
        return 2 * 3.14 * r;
    };
    Circle.prototype.areaOfCircle = function (r) {
        return r * r;
    };
    return Circle;
}());
exports.Circle = Circle;
