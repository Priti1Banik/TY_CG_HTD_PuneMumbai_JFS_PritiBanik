alert('want to proceed?');

//confirm method
var inputFromUser=confirm('are you fine?');
console.log('inputFromUser');

//prompt method
var userName=prompt('are you fine?');
console.log('userName');

console.log('12345');

document.write('hello girls..');