var myString = `Javascript also abbriviated as JS is a scripting language and is very
 important for from end development
Also it is the only language understand by browser`

console.log(myString);

var name='Priti';
var role='Analyst';
var place='Kolkata';
console.log(`I am ${name} and i worked as ${role} and my location is ${place}`);
console.log(`the sum of 1234 and 2451 is ${1234+2451}`);