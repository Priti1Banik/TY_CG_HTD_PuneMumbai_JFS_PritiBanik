//anonymous function
var x=function(){
    console.log('Anonymous function');
}
 
//calling of function
x();   

//naming function
function add(a,b){
    console.log(a+b);
}

//calling of naming function
add(10,16);

//immediate invoke function expression
(function() {
console.log('IIFE is being executed');
})();
(function(x,y) {
    console.log('The value is '+x*y);
    })(27,118);
    
    //understanding the return keyword
    function division(a,b){
        return a/b;
    }
   console.log( division(10,2));