localStorage.setItem('name','priti');
console.log(localStorage.getItem('name'));
console.log(localStorage.length);
localStorage.clear();
console.log(localStorage.length);

sessionStorage.setItem('name','priti');
console.log(sessionStorage.getItem('name'));
