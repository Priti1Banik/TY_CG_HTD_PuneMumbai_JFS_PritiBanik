
//fat arrow function
let add = (a,b) => {
console.log("the sum is ",a+b);
}

add(13,67);

//fat arrow function with one argument
let printAge = age => {
    console.log("age is "+age);
}

printAge(22);

//fat arrow function with single return statement
let product = (a,b) => a*b;
console.log(product(12,17));