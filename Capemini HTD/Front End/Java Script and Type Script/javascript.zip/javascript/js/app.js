// prompt('Please write your name');
var Myname=49499389389;
Myname="ABCDEFG";
console.log(typeof Myname);
//use to display message on console
var areyougood=true;
console.log(typeof areyougood);