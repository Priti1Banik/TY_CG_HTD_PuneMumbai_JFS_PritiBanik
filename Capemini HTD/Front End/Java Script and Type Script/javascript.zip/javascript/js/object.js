//object creation(literal way of object creation)
var student = {
    name: 'Priti',
    age: 22,
    degree: 'B.Tech',
    phoneNumber: 1234567890
};

console.log(student.name);
console.log(student);

//changing of value in object
student.phoneNumber=7689282638;
console.log(student.phoneNumber);

//if we want to add more key-value pairs
student.selectedCompany='capgemini';
console.log(student);

//creation of object using object constructor
var laptop = new Object();
laptop.brand = 'HP';
laptop.ram = '8GB';
laptop.processor = 'i5';
laptop.price = 48000;
console.log(laptop);

//length of object
console.log(Object.keys(laptop).length);