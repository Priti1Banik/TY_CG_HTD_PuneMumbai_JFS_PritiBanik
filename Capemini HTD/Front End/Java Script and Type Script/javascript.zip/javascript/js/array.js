var x = [12345,'abcd',true,{name:'Deepika Padukone'}];
console.log(x[0]);
console.log(x[3]);
for(var i=0;i<x.length;i++){
    console.log(x[i]);
}
var colors = ['red','yellow','black','violet','navyblue'];
console.log(colors);
colors.pop();
console.log(colors);
colors.push('pink','mud');
console.log(colors);
colors.shift();
console.log(colors);
colors.unshift('magenda','crimson');
console.log(colors);
colors.splice(2,1);
console.log(colors);
colors.splice(3,0,'orange','indigo');
console.log(colors);

// setTimeout(function(){
//     console.log('3 seconds done');
// },3000);


// var i = 1;
// setInterval(function(){
// console.log(i);
// i++
// },1);

//call back function
// function test(cb){
//     console.log('test function started');
//     cb();
//     console.log('test function ended');
// }

// test(function(){
//     console.log('call back function is being executed');
// });

// setTimeout(function(){
//     console.log('3 seconds done');
// },3000);

colors.forEach(function(value,index,array){
    console.log(value,index,array)
});

var myArray=[101,102,105,117,120,130,140,105,117,117];
var x =myArray.filter(function(value){
    return value>110;
});

console.log(x);

//filter method for uniques values
var filteredArray = myArray.filter(function(value,index,array) {
    return array.indexOf(value)===index;
});
console.log(filteredArray);
 //== doesnot check datatype and give result as true
if(123 == '123'){
    console.log(true);
}else{
    console.log(false);
}
//=== check for data as well as datatype and will give result as false
if(123==='123'){
    console.log(true);
}else{
    console.log(false);
}

for(var x of myArray){
    console.log(x);
}
for(var index in colors){
    console.log('The color is '+colors[index]+ ' and the index is '+index);
}


var movie = {
    name: 'Arjun Reddy',
    actor: 'Vijaya Deverakonda',
    actress: 'Shalini Pandey',
    rating: 'very good'
};
for(var key in movie){
    console.log(key);
    console.log(movie[key]);
}