let person = {
    name: 'kajal',
    age: 30,
};

let student = {
    ...person,
    uid: 1234,
    percentage:68.78
};
console.log(student);

let myArray=[1,2,3,4,5,6];
let myArray1=[...myArray,7,8,9,10];
console.log(myArray1);

Mumbai=['ABCD','PQRS'];
Noida=['RETS','TGFE'];
Bangalore=['WERT','TYUS'];
Pune=['VCBS','KLMN'];
Combine=[
    ...Mumbai,
    ...Noida,
    ...Bangalore,
    ...Pune,
      'MNOP'
];
console.log(Combine);

let [name1,name2,name3,...restValues]=Combines;
console.log(name1);
console.log(name2);
console.log(name3);
console.log(restValues);

