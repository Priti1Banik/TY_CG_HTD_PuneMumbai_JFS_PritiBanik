let myString = 'Capgemini students are good';

//indexOf check for index and display it
console.log(myString.indexOf('are'));

//includes check whether string present or not
console.log(myString.includes('train'));

//split,reverse and join together is use for string reversal
console.log(myString.split('').reverse().join(''));

//charAt will give the character present at index 2
console.log(myString.charAt(2));

//this charCodeAt will give ascii value of the element present at index 1
console.log(myString.charCodeAt(1));