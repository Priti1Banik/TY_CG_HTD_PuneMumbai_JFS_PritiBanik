class Student {
    constructor(
    public name: string,
    public age: number,
    public marks: number,
    public degree ?: string,
    public id ?: string
)
{

}
// printDetails(){
// console.log(`Name is ${this.name} age is ${this.age} and marks is ${this.marks}`);
// }
 }

 //object creation using new keyword
let student1 = new Student('Priti',22,82);
console.log(student1);
//student1.printDetails();

//object creation using literals
let student2: Student={
    name:'Sneha',
    age: 27,
    marks: 83
}
console.log(student2);

//array
let students: Student[] = [
    new Student('Saheli',29,78),
    {
       name: 'ABCD',
       age: 30,
       marks: 77
    },
    student2,
    student1
];

for(let Student of students){
    console.log(Student);
}

class Graduate extends Student{
    constructor(
  public name: string,
  public age: number,
  public marks: number
    ){
        super(name,age,marks);
    }
}