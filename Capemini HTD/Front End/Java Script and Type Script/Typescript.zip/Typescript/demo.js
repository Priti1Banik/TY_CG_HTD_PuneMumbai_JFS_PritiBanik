var myName = 'Priti';
//myName=1234; error-we cannot change the data type
var company; //implicitlyit will be consider as any
company = 1234;
company = 'capgemini';
company = true;
//union
var age; //union- it capable of holding different datatype in single variable but boolean is not possible to store
//tuple
var details = ['ABCD', 1234, 5678]; //form of array which can store particular type of data
//array
var mobiles = ['iphone', 'samsung', '5555', 'true', 'false']; //to make array hompogeneous use datatype
//functions
function add(a, b) {
    return a + b;
}
