let myName: string = 'Priti';
//myName=1234; error-we cannot change the data type

let company;    //implicitlyit will be consider as any
company=1234;
company='capgemini';
company=true;

//union
let age: string | number;     //union- it capable of holding different datatype in single variable but boolean is not possible to store

//tuple
let details: [string,number,number] = ['ABCD',1234,5678];  //form of array which can store particular type of data

//array
let mobiles: string[] = ['iphone','samsung','5555','true','false']; //to make array hompogeneous use datatype

//functions
function add(a: number,b: number): number{   //specify the datatype of parameter to make the function use homogeneous element.Also mention the datatype of return type before curly braces started
return a+b;
}




















